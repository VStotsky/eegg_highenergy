{G[{0}, T] -> Log[T], G[{1}, T] -> Log[1 - T], G[{0, 0}, T] -> Log[T]^2/2, 
 G[{0, 1}, T] -> -PolyLog[2, T], G[{1, 0}, T] -> 
  Log[1 - T]*Log[T] + PolyLog[2, T], G[{1, 1}, T] -> Log[1 - T]^2/2, 
 G[{0, 0, 0}, T] -> Log[T]^3/6, G[{0, 0, 1}, T] -> -PolyLog[3, T], 
 G[{0, 1, 0}, T] -> -(Log[T]*PolyLog[2, T]) + 2*PolyLog[3, T], 
 G[{0, 1, 1}, T] -> (Log[1 - T]^2*Log[T])/2 + Log[1 - T]*PolyLog[2, 1 - T] - 
   PolyLog[3, 1 - T] + Zeta[3], G[{1, 0, 0}, T] -> 
  (Log[1 - T]*Log[T]^2)/2 + Log[T]*PolyLog[2, T] - PolyLog[3, T], 
 G[{1, 0, 1}, T] -> -(Log[1 - T]^2*Log[T]) - 2*Log[1 - T]*PolyLog[2, 1 - T] - 
   Log[1 - T]*PolyLog[2, T] + 2*PolyLog[3, 1 - T] - 2*Zeta[3], 
 G[{1, 1, 0}, T] -> Log[1 - T]^2*Log[T] + Log[1 - T]*PolyLog[2, 1 - T] + 
   Log[1 - T]*PolyLog[2, T] - PolyLog[3, 1 - T] + Zeta[3], 
 G[{1, 1, 1}, T] -> Log[1 - T]^3/6, G[{0, 0, 0, 0}, T] -> Log[T]^4/24, 
 G[{0, 0, 0, 1}, T] -> -PolyLog[4, T], G[{0, 0, 1, 0}, T] -> 
  -(Log[T]*PolyLog[3, T]) + 3*PolyLog[4, T], 
 G[{0, 0, 1, 1}, T] -> Pi^4/90 + (Pi^2*Log[1 - T]^2)/12 + 
   (Log[1 - T]^3*Log[(1 - T)/T^4])/24 - Log[1 - T]*PolyLog[3, T] - 
   PolyLog[4, 1 - T] + PolyLog[4, T] + PolyLog[4, T/(-1 + T)] + 
   Log[1 - T]*Zeta[3], G[{0, 1, 0, 0}, T] -> -1/2*(Log[T]^2*PolyLog[2, T]) + 
   2*Log[T]*PolyLog[3, T] - 3*PolyLog[4, T], 
 G[{0, 1, 0, 1}, T] -> PolyLog[2, T]^2/2 - 
   2*(Pi^4/90 + (Pi^2*Log[1 - T]^2)/12 + (Log[1 - T]^3*Log[(1 - T)/T^4])/24 - 
     Log[1 - T]*PolyLog[3, T] - PolyLog[4, 1 - T] + PolyLog[4, T] + 
     PolyLog[4, T/(-1 + T)] + Log[1 - T]*Zeta[3]), 
 G[{0, 1, 1, 0}, T] -> -1/2*PolyLog[2, T]^2 + 
   Log[T]*((Log[1 - T]^2*Log[T])/2 + Log[1 - T]*PolyLog[2, 1 - T] - 
     PolyLog[3, 1 - T] + Zeta[3]), G[{0, 1, 1, 1}, T] -> 
  -1/90*Pi^4 + (Log[1 - T]^3*Log[T])/6 + (Log[1 - T]^2*PolyLog[2, 1 - T])/2 - 
   Log[1 - T]*PolyLog[3, 1 - T] + PolyLog[4, 1 - T], 
 G[{1, 0, 0, 0}, T] -> (Log[1 - T]*Log[T]^3)/6 + (Log[T]^2*PolyLog[2, T])/2 - 
   Log[T]*PolyLog[3, T] + PolyLog[4, T], G[{1, 0, 0, 1}, T] -> 
  -1/2*PolyLog[2, T]^2 - Log[1 - T]*PolyLog[3, T], 
 G[{1, 0, 1, 0}, T] -> Pi^4/45 + (Pi^2*Log[1 - T]^2)/6 + 
   (Log[1 - T]^3*Log[(1 - T)/T^4])/12 - Log[1 - T]^2*Log[T]^2 - 
   2*Log[1 - T]*Log[T]*PolyLog[2, 1 - T] - Log[1 - T]*Log[T]*PolyLog[2, T] + 
   PolyLog[2, T]^2/2 + 2*Log[T]*PolyLog[3, 1 - T] - 2*PolyLog[4, 1 - T] + 
   2*PolyLog[4, T] + 2*PolyLog[4, T/(-1 + T)] + 2*Log[1 - T]*Zeta[3] - 
   2*Log[T]*Zeta[3], G[{1, 0, 1, 1}, T] -> 
  Pi^4/30 - (Log[1 - T]^2*PolyLog[2, 1 - T])/2 + 
   2*Log[1 - T]*PolyLog[3, 1 - T] - 3*PolyLog[4, 1 - T] + Log[1 - T]*Zeta[3], 
 G[{1, 1, 0, 0}, T] -> -1/90*Pi^4 - (Pi^2*Log[1 - T]^2)/12 - 
   (Log[1 - T]^3*Log[(1 - T)/T^4])/24 + (3*Log[1 - T]^2*Log[T]^2)/4 + 
   Log[1 - T]*Log[T]*PolyLog[2, 1 - T] + Log[1 - T]*Log[T]*PolyLog[2, T] - 
   Log[T]*PolyLog[3, 1 - T] + PolyLog[4, 1 - T] - PolyLog[4, T] - 
   PolyLog[4, T/(-1 + T)] - Log[1 - T]*Zeta[3] + Log[T]*Zeta[3], 
 G[{1, 1, 0, 1}, T] -> -1/30*Pi^4 - (Log[1 - T]^3*Log[T])/2 - 
   (Log[1 - T]^2*PolyLog[2, 1 - T])/2 - (Log[1 - T]^2*PolyLog[2, T])/2 - 
   Log[1 - T]*PolyLog[3, 1 - T] + 3*PolyLog[4, 1 - T] - 2*Log[1 - T]*Zeta[3], 
 G[{1, 1, 1, 0}, T] -> (Pi^4 + 45*Log[1 - T]^3*Log[T] + 
    45*Log[1 - T]^2*PolyLog[2, 1 - T] + 45*Log[1 - T]^2*PolyLog[2, T] - 
    90*PolyLog[4, 1 - T] + 90*Log[1 - T]*Zeta[3])/90, 
 G[{1, 1, 1, 1}, T] -> Log[1 - T]^4/24}
