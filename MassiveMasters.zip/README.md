# Massive master integrals for two-loop QED $l^+l^-\to\gamma\gamma$.

IMPORTANT!!! this files contains the master integrals, slightly different from the work https://arxiv.org/abs/2410.03336. The difference is in 12 integrals, which is easy to obtain, for example, using the ToMIsRule[] command from LiteRed2.

## File descriptions
$mm$ in files means $m^2$

### `ggs.m`

File contains definitons ggs of LiteRed-bases.

### `toJrules`

This file contains the rules for the passing from 165 master integrals to canonical integrals, denoted by J. As well as the master of integrals, in which the substitution $t\to2m^2-t-s$ ($T \to 1-T$) is made (the bases of which are denoted by $gg_{i}c$) through canonical integrals with the same substitution, which are denoted by Jc
notation: $t \to mm - T, d \to 4 - 2\epsilon$
### `Jviaut/Jut.l` and `Jviaut/Jcut.l`` with $l = 1,\dots,165$

This 330 files contains expressions for canonical integrals J and Jc via $ut(T,\epsilon)$ and $utc(T,\epsilon)$ functions. $ut$ functions is uniformly transcendental.
Each file `Jut.l` or `Jcut.l`  has the form of a double array, with the first index running through the seven contributions from $m^{2\lambda}$, with the second index running through the coefficients in front of $m^{2n}$, with $n=0,\dots,6$.

### `utTU10`

This is uniformly transcendental functions $ut$ and $utc$ of T and \epsilon via \epsilon-series through \epsilon^{10}. Array of 330 functions, last 165 funcitons is $utc$ funcitons.

### `Grules.m`

This is rules for Goncharov's to classical polylogarithms for weights $\le 4$

### `Example.nb`

A file that shows how to apply the above files to massively expand a combination of master integrals and express them in terms of polylogarithms.

