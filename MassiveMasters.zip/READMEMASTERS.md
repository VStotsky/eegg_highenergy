# Massive master integrals for two-loop QED $l^+l^-\to\gamma\gamma$.

IMPORTANT!!! this files contains the master integrals, slightly different from the work https://arxiv.org/abs/2410.03336. The difference is in 12 integrals, which is easy to obtain, for example, using the ToMIsRule[] command from LiteRed2.

## File descriptions
$mm$ in files means $m^2$

### `ggs.m`

File contains definitons ggs of LiteRed-bases.

### `toJrules`

This file contains the transformation rules from the 165 master integrals to the canonical integrals (denoted by $J$). It also includes the rules for the crossed master integrals, obtained via the substitution $t\to2m^2-t-s$ (equivalently $T \to 1-T$). These changed masters are denoted by $gg_{i}c$ and their corresponding canonical integrals (under the same substitution) are denoted by $Jc$.
notation: $t \to mm - T, d \to 4 - 2\epsilon$
### `Jviaut/Jut.l` and `Jviaut/Jcut.l` with $l = 1,\dots,165$

These 330 files contain expressions for the canonical integrals $J$ and $Jc$ via $ut(T,\epsilon)$ and $utc(T,\epsilon)$ functions. The $ut$ and $utc$ functions are uniformly transcendental.
Each file `Jut.l` or `Jcut.l`  has the form of a two-dimensional array. Runs over the seven contributions corresponding to powers $m^{2\lambda}$. Second index runs over the coefficients in front of $m^{2n}$, with $n=0,\dots,6$.

### `utTU10`

This is uniformly transcendental functions $ut$ and $utc$ of T and \epsilon via \epsilon-series through \epsilon^{10}. Array of 330 functions, last 165 funcitons is $utc$ funcitons.

### `Grules.m`

This is rules for Goncharov's to classical polylogarithms for weights $\le 4$

### `Example.nb`

A file that shows how to apply the above files to massively expand a combination of master integrals and express them in terms of polylogarithms.

